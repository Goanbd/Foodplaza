<!DOCTYPE html>

<html lang="zxx">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>online</title>

    <style>

        #bb

        {

            width: 100%;

        }

    </style>

</head>

<body>

    <div class="cc">

        <a href="1st.php"><img src="nahjdbdbbxbxxhxbbsbwsb.png" alt="" id="bb"></a>

    </div>

</body>

</html>
